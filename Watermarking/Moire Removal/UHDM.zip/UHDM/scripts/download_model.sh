mkdir pretrain_model
cd pretrain_model

gdown https://drive.google.com/uc?id=1PyCLCytsu4F8gEk_04a8Qs7pcsHazAie # uhdm_large
gdown https://drive.google.com/uc?id=1HT_ubcAYRqzFIJ46XuPhrulJk2YFBIEl # uhdm
gdown https://drive.google.com/uc?id=1oqmpBM-3gDwEKRMKoS6cKT0-3_EzBPAf # tip_large
gdown https://drive.google.com/uc?id=1CcYDakV9r6sZTsJvdkzC-uutAlOrexW8 # tip
gdown https://drive.google.com/uc?id=1Fwx0b2jJHgx4cgqrd8d_4er2UGYbZO0s # fhdmi_large
gdown https://drive.google.com/uc?id=19GaA5F7aTUUrgZig4qlR8ISe23mPc8m_ # fhdmi
gdown https://drive.google.com/uc?id=114EDQnJ0AUEGiXFmA9Hiwj_m7sj1KyNW # aim_large
gdown https://drive.google.com/uc?id=1WWFz-BYpW9QAwGGSy7hVPSDNT0DARnhZ # aim

