mkdir uhdm_data
cd uhdm_data

gdown https://drive.google.com/uc?id=1NiTohc65FZZXvmFpI80OTczp5Vc6EGDe
tar zxvf  train.tar.gz
gdown https://drive.google.com/uc?id=1bAZRuDq_bxZgxvnGtLwORV9pFKq2_kM_
tar zxvf  test.tar.gz
gdown https://drive.google.com/uc?id=1SGVXv1Ce8UXL1eI3WaTmArAo6huUYgC0
tar zxvf  test_origin.tar.gz